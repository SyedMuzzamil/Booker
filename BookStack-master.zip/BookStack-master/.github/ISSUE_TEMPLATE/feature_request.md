---
name: Feature request
about: Suggest an idea for this project

---

**Describe the feature you'd like**
A clear description of the feature you'd like implemented in BookStack.

**Describe the benefits this feature would bring to BookStack users**
Explain the measurable benefits this feature would achieve.

**Additional context**
Add any other context or screenshots about the feature request here.
