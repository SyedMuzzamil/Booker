<?php namespace BookStack\Exceptions;

class ImageUploadException extends PrettyException
{

}
