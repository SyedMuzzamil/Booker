<?php namespace BookStack\Exceptions;

class PrettyException extends \Exception
{

}
