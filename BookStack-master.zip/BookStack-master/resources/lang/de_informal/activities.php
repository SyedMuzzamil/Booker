<?php

// Extends 'de'
return [
    //
];