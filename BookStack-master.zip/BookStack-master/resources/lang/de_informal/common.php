<?php

// Extends 'de'
return [
    /**
     * Email Content
     */
    'email_action_help' => 'Sollte es beim Anklicken der Schaltfläche ":action_text" Probleme geben, öffne die folgende URL in Deinem Browser:',
];