<?php
/**
 * Pagination Language Lines
 * The following language lines are used by the paginator library to build
 * the simple pagination links.
 */
return [

    'previous' => '&laquo; Previous',
    'next'     => 'Next &raquo;',

];
